This code is written in python3.

pip3 install -r requirements.txt

Question 5(a):

    Plots a minkowski C-Space.

Question 5(b):

    Plots a 3D C-Space.

Question 7(a):

    It will as if you want to implement Forward or Inverse kinematics.

    If you choose Forward:

        It will ask the length and angles of the links.

        Plots all the links with its points and end-effector.
    
    If you choose Inverse:

        It will ask the length of the links and end-effector.

        Plots one of the configuration with all the links with end-effector.

Question 8:

    It will ask coordinates of all the obstacles.

    Plots the obstacles and the C-Space.